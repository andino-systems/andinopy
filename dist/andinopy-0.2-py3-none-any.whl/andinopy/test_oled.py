

import andinopy.base_devices.andino_io_oled

myled = andinopy.base_devices.andino_io_oled.andino_io_oled()
myled.rot = 1

myled.set_text([["hehehhehe","hohohohoho"],["huhu","hihi"]])